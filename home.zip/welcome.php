<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style/welcome.css">
    <title>Saujenhi</title>
</head>
<body>
    <div class="container">
        <h1>Annyeong<br>Your Culinary<br> Journey Starts Here!</h1>
        <div class="inner-container">
          <a href="login.php" class="button">Masuk</a>
          <p>Belum Punya Akun? <a href="register.php" class="register">Daftar</a></p>
        </div>
    </div>
</body>
</html>