<?php
// Konfigurasi koneksi database
$server_name = "localhost";
  $username = "root";
  $password = "";
  $db_name = "saujenhi";


try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Ambil data dari form
    $username = $_POST['username'];
    $plainPassword = $_POST['password'];
    $email = $_POST['email'];
    $role = $_POST['role'];

    // Hash password
    $hashedPassword = password_hash($plainPassword, PASSWORD_DEFAULT);

    // Query untuk menyimpan data
    $sql = "INSERT INTO pengguna (username, password, email, role, created_at, updated_at)
            VALUES (:username, :password, :email, :role, NOW(), NOW())";
    $stmt = $pdo->prepare($sql);

    // Bind parameter dan eksekusi
    $stmt->bindParam(':username', $username);
    $stmt->bindParam(':password', $hashedPassword);
    $stmt->bindParam(':email', $email);
    $stmt->bindParam(':role', $role);

    if ($stmt->execute()) {
        echo "Pengguna baru berhasil ditambahkan!";
    } else {
        echo "Gagal menambahkan pengguna.";
    }
} catch (PDOException $e) {
    echo "Error: " . $e->getMessage();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tambah Pengguna</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 20px;
            padding: 20px;
        }
        form {
            max-width: 400px;
            margin: auto;
            padding: 20px;
            border: 1px solid #ccc;
            border-radius: 10px;
            background-color: #f9f9f9;
        }
        input, select, button {
            width: 100%;
            margin-bottom: 15px;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
        }
        button {
            background-color: #28a745;
            color: white;
            font-size: 16px;
        }
        button:hover {
            background-color: #218838;
        }
    </style>
</head>
<body>
    <h2 style="text-align: center;">Tambah Pengguna</h2>
    <form action="proses_tambah_pengguna.php" method="POST">
        <label for="username">Username:</label>
        <input type="text" id="username" name="username" required>

        <label for="password">Password:</label>
        <input type="password" id="password" name="password" required>

        <label for="email">Email:</label>
        <input type="email" id="email" name="email" required>

        <label for="role">Role:</label>
        <select id="role" name="role">
            <option value="admin">Admin</option>
            <option value="user" selected>User</option>
        </select>

        <button type="submit">Tambah Pengguna</button>
    </form>
</body>
</html>
