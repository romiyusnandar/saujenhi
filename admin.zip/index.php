<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Saujenhi</title>
</head>
<body>
  <div style="display: flex; flex-direction:column; justify-content:center; align-items:center;">
    <h1><?php echo "Saujenhi landingpage" ?></h1>
    <a href="admin">Masuk ke admin dashboard</a>
  </div>
</body>
</html>